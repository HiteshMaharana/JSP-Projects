<%@ page language="java" contentType="text/html; charset=UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<title>Addition</title>
</head>

<body>

<h2>Add Two Numbers</h2>

<form action="result.jsp" method="post">

Enter Number 1:
<input type="number" name="num1"><br><br>

Enter Number 2:
<input type="number" name="num2"><br><br>

<input type="submit" value="Add">

</form>

</body>
</html>