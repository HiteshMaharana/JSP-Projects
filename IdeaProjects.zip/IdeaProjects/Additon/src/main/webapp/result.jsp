<%@ page language="java" contentType="text/html; charset=UTF-8"%>

<%
int n1 = Integer.parseInt(request.getParameter("num1"));
int n2 = Integer.parseInt(request.getParameter("num2"));

int sum = n1 + n2;
%>

<!DOCTYPE html>
<html>
<head>
<title>Result</title>
</head>

<body>

<h2>Addition Result</h2>

Sum = <%= sum %>

</body>
</html>