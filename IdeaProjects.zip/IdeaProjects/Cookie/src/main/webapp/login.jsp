<!DOCTYPE html>
<html>
<head>
<title>Login</title>
</head>

<body>

<h2>Enter Username</h2>

<form action="setCookie.jsp" method="post">

Username:
<input type="text" name="username"><br><br>

<input type="submit" value="Login">

</form>

</body>
</html>