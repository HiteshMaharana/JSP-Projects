<%
String user = request.getParameter("username");

Cookie c = new Cookie("username", user);

c.setMaxAge(60*60);   // 1 hour

response.addCookie(c);

response.sendRedirect("welcome.jsp");
%>