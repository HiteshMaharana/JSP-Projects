<%
Cookie cookies[] = request.getCookies();

String user = "";

if(cookies != null){

for(Cookie c : cookies){

if(c.getName().equals("username")){
user = c.getValue();
}

}
}
%>

<!DOCTYPE html>
<html>
<head>
<title>Welcome</title>
</head>

<body>

<h2>Welcome <%= user %></h2>

</body>
</html>