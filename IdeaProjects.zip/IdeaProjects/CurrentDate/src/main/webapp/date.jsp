<%@ page import="java.util.Date" %>

<!DOCTYPE html>
<html>
<head>
<title>Date and Time</title>
</head>

<body>

<h2>Current Date and Time</h2>

<%
Date d = new Date();
%>

<p><%= d %></p>

</body>
</html>