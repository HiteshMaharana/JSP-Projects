import java.util.Scanner;
class reverse{
    int n;
    void getdata(int i){
        n=i;
    }
    void putdata(){
        int rev=0;
        while(n>0){
            rev=(rev*10)+n%10;
            n=n/10;
        }
        System.out.println("The reverse of a number is:"+rev);
    }
}
public class ArgumentInClass_ObjectOfReverse {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number:");
        int m;
        m=sc.nextInt();
        reverse aa=new reverse();
        aa.getdata(m);//call
        aa.putdata();

    }
}
