import java.util.Scanner;
public class Armstrong {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n,z,count=0,sum=0;
        System.out.print("Enter an integer: ");
        n = sc.nextInt();
        z=n;
        while(z>0){
            count=count+1;
            z=z/10;
        }
        z=n;
        int pro,i,digit;
        while(z>0){
            digit=z%10;
            pro=1;
            for(i=1;i<=count;i++)
                pro=pro*digit;
            sum=sum+pro;
            z=z/10;
        }

        if(sum==n){
            System.out.println("It'a a armstrong number");
        }
        else{
            System.out.println("It's not a armstrong number");
        }
    }
}
