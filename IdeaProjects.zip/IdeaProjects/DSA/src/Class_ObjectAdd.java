import java.util.Scanner;
class add{
    int a,b;//input
    void getdata(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 1st number:");
        a=sc.nextInt();
        System.out.println("Enter 2nd number:");
        b=sc.nextInt();
    }
    void putdata(){
        System.out.println("The sum of a+b="+(a+b));
    }
}
public class Class_ObjectAdd {
    public static void main(String[] args) {
        //create object
        add aa=new add();
        aa.getdata();
        aa.putdata();
    }
}
