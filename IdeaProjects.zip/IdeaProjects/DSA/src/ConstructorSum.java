import java.util.Scanner;

class Sum{
    int a, b;

    Sum() {
        a = 0;
        b = 0;
    }

    // Parameterized constructor
    Sum(int x, int y) {
        a = x;
        b = y;
    }

    // Input section
    void input() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter 1st number: ");
        a = sc.nextInt();
        System.out.print("Enter 2nd number: ");
        b = sc.nextInt();
    }

    void display() {
        System.out.println("a = " + a+ ", b = " + b);
    }

    void output() {
        int c = a + b;
        System.out.println("The sum is : " + c);
    }
}

// Public class (must match file name)
public class ConstructorSum {
    public static void main(String[] args) {
        // Default constructor object
//        Sum aa = new Sum();
//        aa.display();
//        aa.input();
//        aa.output();

        // Parameterized constructor object
        Add bb = new Add(3, 5);
        bb.output();
    }
}
