import java.util.Scanner;
public class Palindrome {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n,rev=0,num;
        System.out.print("Enter a number: ");
        n = input.nextInt();
        num=n; //original value store
        while(n>0){
            rev=(rev*10)+n%10;
            n=n/10;
        }
        if(rev==num){
            System.out.println("The originaal number is:"+num);
            System.out.println("It's a Palindrome:"+rev);
        }
    }
}