import java.util.Scanner;
class Add{
    int a,b;
    Add(int x,int y){
        a=x;
        b=y;
    }
    void output(){
        int c;
        c=a+b;
        System.out.println("The sum is:"+c);
    }


}
public class ParamerizedSum  {
    public static void main(String[] args) {
        int m,n;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the 1st number:");
        m=sc.nextInt();
        System.out.println("Enter the 2nd number:");
        n=sc.nextInt();

        Add aa =new Add(m,n);
        aa.output();

    }
}