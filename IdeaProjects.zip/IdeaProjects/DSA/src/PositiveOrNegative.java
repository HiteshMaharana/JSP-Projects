import java.util.Scanner;
public class PositiveOrNegative {
    public static void main(String[] args) {
        int num;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        num = sc.nextInt();
        if(num>0){
            System.out.println("It's a postive number:"+num);
        }else if(num<0) {
            System.out.println("It's a negative number:"+num);
        }else{
            System.out.println("Number in Zero");
        }
    }
}
