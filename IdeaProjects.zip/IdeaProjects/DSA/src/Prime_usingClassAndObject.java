import java.util.Scanner;
class Prime{
    int n;
    void getdata(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter number");
        n=sc.nextInt();
    }
    void putdata(){
        int i, count=0;
        for(i=1;i<=n;i++){
            if(n%i==0){
                count=count+1;
            }
        }
        if(count==2){
            System.out.println("Prime Number");
        }else {
            System.out.println("Not Prime Number");
        }
    }
}
public class Prime_usingClassAndObject {
    public static void main(String[] args) {
        //accss and create object
        Prime aa =new Prime();
        aa.getdata();
        aa.putdata();
    }
}
