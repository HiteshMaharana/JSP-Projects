import java.util.Scanner;
public class SumOfEvenOddDigits {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n,sum=0,pro=1,digits;
        System.out.println("Enter the number :");
        n=sc.nextInt();
        while(n>0){
            digits=n%10;
            if(digits%2==0){
                sum=sum+digits;
            }
            else {
                pro=pro*digits;
            }
            n=n/10;
        }
        System.out.println("The sum of even number is:"+sum);
        System.out.println("The sum of odd number is:"+pro);
    }
}
