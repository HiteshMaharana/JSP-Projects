import java.util.Scanner;
public class Table {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int i,j=1;
        System.out.println("Enter the number of rows in the table");
        i=sc.nextInt();
        while(j<=10){
            System.out.println(i+"*"+j+"="+i*j);
            j++;
        }
    }
}
