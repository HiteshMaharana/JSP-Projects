//import java.util.Scanner;
//public class calculator {
//    public static void main(String[] args) {
//        int a,b,cal;
//        Scanner sc = new Scanner(System.in);
//        System.out.print("Enter a 2 number: ");
//        a=sc.nextInt();
//        b=sc.nextInt();
//        System.out.println("Chooice 1- , 2-sub , 3-mul , 4-divide :");
//        cal=sc.nextInt();
//        if(cal==1){
//            System.out.println("The Addition is:"+(a+b));
//        }else if(cal==2){
//            System.out.println("The Subtraction is:"+(a-b));
//        }else if(cal==3){
//            System.out.println("The Multiplication is:"+(a*b));
//        }else if(cal==4){
//            System.out.println("The Division is:"+(a/b));
//        }else {
//            System.out.println("Invalid Input");
//        }
//    }
//}

//Using Switch case
import java.util.Scanner;
public class calculator {
    public static void main(String[] args) {
        int a,b,cal;
        System.out.println("Enter 2 number");
        Scanner sc = new Scanner(System.in);
        a=sc.nextInt();
        b=sc.nextInt();
        System.out.println("Chooice 1-add , 2-sub , 3-mul , 4-divide :");
        cal=sc.nextInt();
        switch(cal){
            case 1: System.out.println("The additon is:"+(a+b));
            break;
            case 2: System.out.println("The subtraction is:"+(a-b));
            break;
            case 3: System.out.println("The multiplication is:"+(a*b));
            break;
            case 4: System.out.println("The division is:"+(a/b));
            break;
            case 5: System.out.println("The remainder is:"+(a%b));
            break;
            case 6: System.out.println("Invalide");
        }
    }
}