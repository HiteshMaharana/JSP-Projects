import java.util.Scanner;

public class demo {
    public static void  main(String args[]) {
        int lenth,br,area;
        System.out.print("Enter the number for lenth:");
        Scanner sc = new Scanner(System.in);
        lenth = sc.nextInt();
        System.out.print("Enter the number for br:");
        br = sc.nextInt();
        area = lenth * br;
        System.out.println("The area of the triangle is: " + area);
    }
}
