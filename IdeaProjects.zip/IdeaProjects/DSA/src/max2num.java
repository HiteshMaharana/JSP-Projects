//import java.util.Scanner;
//public class max2num {
//    public static void main(String[] args) {
//    int a,b;
//    System.out.println("Enter the number for a:");
//    Scanner sc=new Scanner(System.in);
//    a=sc.nextInt();
//    System.out.println("Enter the number for b:");
//    b=sc.nextInt();
//    if(a>b){
//        System.out.println("a is the maximum number is :"+a);
//    }else {
//        System.out.println("b is the maximum number is :"+b);
//    }
//    }
//}

//MAX btn 3num
import java.util.Scanner;
public class max2num {
    public static void main(String[] args) {
        int a,b,c;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number for a:");
        a=sc.nextInt();
        System.out.println("Enter the number for b:");
        b=sc.nextInt();
        System.out.println("Enter the number for c:");
        c=sc.nextInt();
        if(a>b && a>c){
            System.out.println("a is the greater:"+a);
        }else if(b>a && b>c){
            System.out.println("b is the greater:"+b);
        }else {
            System.out.println("c is the greater:"+c);
        }
    }
}