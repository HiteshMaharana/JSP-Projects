//
//public class printNumbers {
//    public static void main(String[] args){
//        int i;
//        i=1;
//        while(i<=10){
//            System.out.println(i);
//            i++;
//        }
//    }
//}

//Print 1- n
import java.util.Scanner;
public class printNumbers{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int num;
        num = sc.nextInt();
        int i=1;
        while(i<=num){
            System.out.println(i);
            i++;
        }
    }
}