<%
int n = Integer.parseInt(request.getParameter("num"));

String result;

if(n % 2 == 0){
result = "Even Number";
}else{
result = "Odd Number";
}
%>

<!DOCTYPE html>
<html>
<head>
<title>Result</title>
</head>

<body>

<h2>Result</h2>

Number: <%= n %> <br>

Result: <%= result %>

</body>
</html>