<%@ page import="java.sql.*" %>

<%
String user = request.getParameter("username");
String pass = request.getParameter("password");

try{

Class.forName("com.mysql.cj.jdbc.Driver");

Connection con = DriverManager.getConnection(
"jdbc:mysql://localhost:3306/jspauth","root","password");

PreparedStatement ps = con.prepareStatement(
"SELECT * FROM users WHERE username=? AND password=?");

ps.setString(1,user);
ps.setString(2,pass);

ResultSet rs = ps.executeQuery();

if(rs.next()){
response.sendRedirect("home.jsp");
}
else{
out.println("Invalid Login");
}

}catch(Exception e){
out.println(e);
}
%>