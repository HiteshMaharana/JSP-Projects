<!DOCTYPE html>
<html>
<head>
<title>Login</title>
</head>

<body>

<h2>User Login</h2>

<form action="checkLogin.jsp" method="post">

Username:
<input type="text" name="username"><br><br>

Password:
<input type="password" name="password"><br><br>

<input type="submit" value="Login">

</form>

</body>
</html>