<!DOCTYPE html>
<html>
<head>
<title>Register</title>
</head>

<body>

<h2>User Registration</h2>

<form action="saveUser.jsp" method="post">

Username:
<input type="text" name="username"><br><br>

Password:
<input type="password" name="password"><br><br>

<input type="submit" value="Register">

</form>

<br>

<a href="login.jsp">Already have account? Login</a>

</body>
</html>