<%@ page import="java.sql.*" %>

<%
String user = request.getParameter("username");
String pass = request.getParameter("password");

try{

Class.forName("com.mysql.cj.jdbc.Driver");

Connection con = DriverManager.getConnection(
"jdbc:mysql://localhost:3306/jspauth?useSSL=false&allowPublicKeyRetrieval=true",
"root","@Hitesh123");

PreparedStatement ps = con.prepareStatement(
"INSERT INTO users(username,password) VALUES (?,?)");

ps.setString(1,user);
ps.setString(2,pass);

ps.executeUpdate();

out.println("Registration Successful");
out.println("<br><a href='login.jsp'>Login Now</a>");

}catch(Exception e){
out.println(e);
}
%>