<%

String name=request.getParameter("name");
String email=request.getParameter("email");
String branch=request.getParameter("branch");

%>

<html>
<head>
<title>Registration Summary</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="navbar">
<div class="logo">Student Portal</div>
</div>

<div class="container">

<div class="card result">

<h2>Registration Completed</h2>

<p><strong>Name:</strong> <%=name%></p>

<p><strong>Email:</strong> <%=email%></p>

<p><strong>Branch:</strong> <%=branch%></p>

</div>

</div>

</body>
</html>