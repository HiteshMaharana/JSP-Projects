<html>
<head>
<title>Registration</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="navbar">
<div class="logo">Student Portal</div>
</div>

<div class="container">

<div class="card">

<h2>Step 1 : Personal Information</h2>

<form action="step2.jsp" method="post">

<input type="text" name="name" placeholder="Full Name" required>

<button type="submit">Continue</button>

</form>

</div>

</div>

</body>
</html>