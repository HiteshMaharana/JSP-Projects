<%
String name=request.getParameter("name");
%>

<html>
<head>
<title>Registration</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="navbar">
<div class="logo">Student Portal</div>
</div>

<div class="container">

<div class="card">

<h2>Step 2 : Contact Information</h2>

<form action="step3.jsp" method="post">

<input type="hidden" name="name" value="<%=name%>">

<input type="email" name="email" placeholder="Email Address" required>

<button type="submit">Continue</button>

</form>

</div>

</div>

</body>
</html>