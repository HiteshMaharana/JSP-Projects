<%

String name=request.getParameter("name");
String email=request.getParameter("email");

%>

<html>
<head>
<title>Registration</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="navbar">
<div class="logo">Student Portal</div>
</div>

<div class="container">

<div class="card">

<h2>Step 3 : Academic Details</h2>

<form action="result.jsp" method="post">

<input type="hidden" name="name" value="<%=name%>">
<input type="hidden" name="email" value="<%=email%>">

<input type="text" name="branch" placeholder="Branch / Department" required>

<button type="submit">Submit</button>

</form>

</div>

</div>

</body>
</html>