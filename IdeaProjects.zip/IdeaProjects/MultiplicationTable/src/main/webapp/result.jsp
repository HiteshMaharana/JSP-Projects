<%
int n = Integer.parseInt(request.getParameter("num"));
%>

<!DOCTYPE html>
<html>
<head>
<title>Table</title>
</head>

<body>

<h2>Multiplication Table of <%= n %></h2>

<%
for(int i=1;i<=10;i++){
out.println(n + " x " + i + " = " + (n*i) + "<br>");
}
%>

</body>
</html>