<!DOCTYPE html>
<html>
<head>
<title>Multiplication Table</title>
</head>

<body>

<h2>Enter a Number</h2>

<form action="result.jsp" method="post">

Number:
<input type="number" name="num">

<input type="submit" value="Show Table">

</form>

</body>
</html>