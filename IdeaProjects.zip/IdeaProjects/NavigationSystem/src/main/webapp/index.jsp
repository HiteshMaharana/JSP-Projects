<html>

<head>
<title>Navigation System</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="navbar">
<div class="logo">Student Portal</div>
</div>

<div class="container">

<div class="card">

<h2>Enter Your Name</h2>

<form action="home.jsp" method="get">

<input type="text" name="name" placeholder="Your Name" required>

<button type="submit">Continue</button>

</form>

</div>

</div>

</body>

</html>