<%
String name=request.getParameter("name");
%>

<html>

<head>
<title>Profile</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="navbar">

<div class="logo">Student Portal</div>

<div class="nav-links">
<a href="home.jsp?name=<%=name%>">Home</a>
<a href="profile.jsp?name=<%=name%>">Profile</a>
<a href="about.jsp?name=<%=name%>">About</a>
</div>

</div>

<div class="container">

<div class="card">

<h2>User Profile</h2>

<p>Name : <%=name%></p>

</div>

</div>

</body>

</html>