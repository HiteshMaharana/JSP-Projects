<%@ page import="java.util.*" %>

<%

String product=request.getParameter("product");

ArrayList<String> cart=(ArrayList<String>)session.getAttribute("cart");

if(cart==null){
cart=new ArrayList<String>();
}

cart.add(product);

session.setAttribute("cart",cart);

response.sendRedirect("products.jsp");

%>