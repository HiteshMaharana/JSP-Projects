<%@ page import="java.util.*" %>

<html>

<head>
<title>Shopping Cart</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="navbar">

<div class="logo">CoolCart</div>

<div class="nav-links">
<a href="products.jsp">Store</a>
<a href="checkout.jsp">Checkout</a>
</div>

</div>

<div class="container">

<div class="cart-box">

<h2>Your Cart</h2>

<br>

<%

ArrayList<String> cart=(ArrayList<String>)session.getAttribute("cart");

if(cart==null || cart.size()==0){

%>

<p>Your cart is empty</p>

<%

}else{

for(String item:cart){

%>

<p><%=item%></p>

<%

}

}

%>

<br>

<a href="checkout.jsp">
<button>Proceed to Checkout</button>
</a>

</div>

</div>

</body>

</html>