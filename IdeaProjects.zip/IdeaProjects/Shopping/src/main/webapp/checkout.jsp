<%@ page import="java.util.*" %>

<html>

<head>
<title>Checkout</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="navbar">

<div class="logo">CoolCart</div>

</div>

<div class="container">

<div class="cart-box">

<h2>Order Summary</h2>

<br>

<%

ArrayList<String> cart=(ArrayList<String>)session.getAttribute("cart");

if(cart!=null){

for(String item:cart){

%>

<p><%=item%></p>

<%

}

}

%>

<br>

<p>Order placed successfully.</p>

</div>

</div>

</body>

</html>