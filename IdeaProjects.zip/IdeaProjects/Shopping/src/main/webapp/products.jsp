<%@ page import="java.util.*" %>

<html>

<head>
<title>CoolCart Store</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="navbar">

<div class="logo">CoolCart</div>

<div class="nav-links">
<a href="products.jsp">Store</a>
<a href="cart.jsp">Cart</a>
</div>

</div>

<div class="container">

<h2>Products</h2>

<br>

<div class="products">

<div class="card">
<div class="product-title">Laptop</div>
<div class="price">₹50000</div>

<form action="addToCart.jsp" method="post">
<input type="hidden" name="product" value="Laptop">
<button>Add to Cart</button>
</form>

</div>

<div class="card">
<div class="product-title">Smartphone</div>
<div class="price">₹20000</div>

<form action="addToCart.jsp" method="post">
<input type="hidden" name="product" value="Smartphone">
<button>Add to Cart</button>
</form>

</div>

<div class="card">
<div class="product-title">Headphones</div>
<div class="price">₹3000</div>

<form action="addToCart.jsp" method="post">
<input type="hidden" name="product" value="Headphones">
<button>Add to Cart</button>
</form>

</div>

<div class="card">
<div class="product-title">Smart Watch</div>
<div class="price">₹8000</div>

<form action="addToCart.jsp" method="post">
<input type="hidden" name="product" value="Smart Watch">
<button>Add to Cart</button>
</form>

</div>

</div>

</div>

</body>

</html>