<%@ page import="java.util.*" %>

<%
String books[] = request.getParameterValues("book");

if(books != null){

session.setAttribute("cart", books);
}
%>

<!DOCTYPE html>
<html>
<head>
<title>Cart</title>
</head>

<body>

<h2>Your Cart</h2>

<%
String cart[] = (String[])session.getAttribute("cart");

if(cart != null){

for(String b : cart){
out.println(b + "<br>");
}

}else{
out.println("Cart is empty");
}
%>

</body>
</html>