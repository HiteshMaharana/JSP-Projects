<!DOCTYPE html>
<html>
<head>
<title>Shopping Page</title>
</head>

<body>

<h2>Select Book</h2>

<form action="cart.jsp" method="post">

<input type="checkbox" name="book" value="Java Book"> Java Book <br>

<input type="checkbox" name="book" value="Python Book"> Python Book <br>

<input type="checkbox" name="book" value="DSA Book"> DSA Book <br><br>

<input type="submit" value="Add to Cart">

</form>

</body>
</html>