<%
String name = request.getParameter("name");
String roll = request.getParameter("roll");
String course = request.getParameter("course");
%>

<!DOCTYPE html>
<html>
<head>
<title>Student Details</title>
</head>

<body>

<h2>Student Details</h2>

Name: <%= name %> <br><br>

Roll Number: <%= roll %> <br><br>

Course: <%= course %>

</body>
</html>