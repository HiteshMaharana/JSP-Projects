<!DOCTYPE html>
<html>
<head>
<title>Student Form</title>
</head>

<body>

<h2>Student Registration</h2>

<form action="display.jsp" method="post">

Name:
<input type="text" name="name"><br><br>

Roll Number:
<input type="text" name="roll"><br><br>

Course:
<input type="text" name="course"><br><br>

<input type="submit" value="Submit">

</form>

</body>
</html>