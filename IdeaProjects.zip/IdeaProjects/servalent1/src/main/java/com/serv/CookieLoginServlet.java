package com.serv;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/login")
public class CookieLoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String remember = req.getParameter("remember");

        HttpSession session = req.getSession();
        session.setAttribute("username", name);
        session.setAttribute("useremail", email);

        Cookie cookie = new Cookie("userName", name);

        if (remember != null) {
            cookie.setMaxAge(7 * 24 * 60 * 60); // 7 days
        } else {
            cookie.setMaxAge(0); // delete cookie
        }

        resp.addCookie(cookie);

        resp.sendRedirect("home");
    }
}