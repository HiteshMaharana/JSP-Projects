package com.serv;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);

        if (session == null) {
            resp.sendRedirect("login.html");
            return;
        }

        String name = (String) session.getAttribute("username");
        String email = (String) session.getAttribute("useremail");

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        out.println("<h2>Home Page</h2>");
        out.println("<p>Name: " + name + "</p>");
        out.println("<p>Email: " + email + "</p>");

        out.println("<br>");
        out.println("<a href='logout'>Logout</a>");
    }
}