<%@ page import="jakarta.servlet.http.Cookie" %>

<%
String username = "";

Cookie[] cookies = request.getCookies();

if(cookies != null){
    for(Cookie c : cookies){
        if(c.getName().equals("userName")){
            username = c.getValue();
        }
    }
}
%>

<html>
<head>
<title>Login</title>
</head>

<body>

<h2>Login Page</h2>

<form action="login" method="post">

Name:
<input type="text" name="name" value="<%=username%>">
<br><br>

Email:
<input type="email" name="email">
<br><br>

<input type="checkbox" name="remember"> Remember Me
<br><br>

<button type="submit">Login</button>

</form>

</body>
</html>